# Ejemplo de aplicación de citas médicas en React Native.

Ejemplo muy básico para empezar con React Native. Es una aplicación de una sola pantalla donde se ponen en práctica los conceptos de React.JS en React Native.

### Actualización: Async Storage

Se integra Async Storage para guardar las citas en la memoria del movil.

### Screen


<img src="docs/screen1.jpg" height="500">
<img src="docs/screen2.jpg" height="500">
<img src="docs/screen3.jpg" height="500">
<img src="docs/screen4.jpg" height="500">
<img src="docs/screen5.jpg" height="500">