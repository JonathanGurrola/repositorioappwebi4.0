function AlumnoModificar() {
	return ( 
		<>
			<h1>Alumno modificar</h1>
		</>
	 );
}

export default AlumnoModificar;